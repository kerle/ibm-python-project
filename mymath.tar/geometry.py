def area_of_rectangle (a,b):
    return a * b

def area_of_circle (r):
    return 2 * 3.14 * r